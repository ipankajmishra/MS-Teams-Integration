export const config = {
    appId: '05e3f589-2dac-4c32-a0a7-f93d4cd1c2c0',//'9568a0ee-3189-4edc-b23f-adc41a8f2fb9',
    redirectUri: 'http://localhost:3000',
    scopes: [
      'user.read',
      'calendars.read',
      'calendars.readwrite'
    ]
  };