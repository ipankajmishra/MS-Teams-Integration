import React, { Component } from 'react'
import { UserOutlined } from '@ant-design/icons';
import axios from 'axios';
import PropTypes from 'prop-types'
import { Button } from 'semantic-ui-react';
import { List } from 'semantic-ui-react'
import { Avatar  } from 'antd';
import { Divider } from 'semantic-ui-react'
import $ from "jquery";
import { Search, Grid, Header, Segment, Label } from 'semantic-ui-react';

import _ from 'lodash';
// const initialState = { isLoading: false, results: [], value: '' }

const resultRenderer = ({ firstName,lastName }) => <Label content={`${firstName} ${lastName!==null?lastName:''}`} />

resultRenderer.propTypes = {
  firstName: PropTypes.string,
  lastName:PropTypes.string
}

export class ListProfile extends Component {

  constructor(props) {
    super(props);
    this.state = {
      userList: [],
      activeButtonUser:false,
      arr:[],
      lastindex:-1,
      bgColor:[],
      fgColor:[],
      isLoading: false,
       results: [],
        value: '',
        temporaryUserList:[]
      // myActivities: [],
    };
    // this.hello();
  }


  componentDidMount() {
    // let userData = [];
    axios.get(`http://localhost:6769/api/v1/user/UserAccess/allUsers`).then(res => {
      this.setState({
        userList: res.data,
        temporaryUserList:res.data
      })
     
      // let arr = this.state.arr;
      // let length = this.state.userList.length;
      // arr.fill(false);
      // // for(let i=0;i<length;i++){
      // //   arr[i]=false
      // // }
      // this.setState({
      //   arr:arr
      // })
      let bgColor = [];
      let fgColor = [];
      for(let i=0;i<this.state.userList.length;i++){
        bgColor[i]=this.getRandomColor();
        fgColor[i]=this.getRandomColorDark();
      }
      this.setState({
        bgColor:bgColor,
        fgColor:fgColor
      })
      
    })
  }


  handleResultSelect = (e, { result }) => {
    this.setState({ 
    value: (result.firstName + " " + result.lastName===null?"":result.lastName),
    
  })
  if(this.state.results.length>0){
    this.setState({
      userList:this.state.results
    })
  }else{
    this.setState({
      userList:this.state.temporaryUserList
    })
  }
}

  handleSearchChange = (e, { value }) => {
    this.setState({ isLoading: true, value })

    setTimeout(() => {
      if (this.state.value.length < 1) return this.setState({isLoading: false, results: [], value: '',userList:this.state.temporaryUserList})

      const re = new RegExp(_.escapeRegExp(this.state.value), 'i')
      const isMatch = (result) => 
        re.test(result.firstName + " "+result.lastName)
        // re.test(result.lastName)
      
      let result = _.filter(this.state.temporaryUserList, isMatch);
      this.setState({
        isLoading: false,
        results: result
      })
    }, 300)
  }



  handleGetAssignedActivities = (id) => {
    axios.get(`http://localhost:8060/getAllActivityByUser/` + id).then(res => {
      console.log("hello")
      // this.setState({
      //   myActivities: res.data
      // })
      this.props.myActivitiesList(res.data)
    })
  }

  
addActiveState = (classname,id,index) =>{
  if(index!==this.state.lastindex){console.log("im here"+classname)
  let arr = this.state.arr;
  arr[index]=true;
  arr[this.state.lastindex]=false;
  this.setState({
    lastindex:index,
    arr:arr
  })
  // $(classname).removeClass(classname);
  
  this.handleGetAssignedActivities(id);}
}

getRandomColor=()=> {
 var color = "hsl(" + Math.random() * 360 + ", 100%, 90%)";
  return color;
}

getRandomColorDark=()=> {
  var color = "hsl(" + Math.random() * 360 + ", 100%, 30%)";
   return color;
 }

  usercomponent=(user,classname,index)=>{
    return(
    
    <div className="card custom-Card-User">
      <div style={{display:"inline-flex"}}>
    <Avatar style={{ color: this.state.fgColor[index], backgroundColor: this.state.bgColor[index] }}>{user.firstName.substr(0,1)}</Avatar>
    <a onClick={()=>{this.addActiveState(classname,user.userId,index)}} class={`item ${this.state.arr[index]?"active":''}`}>
    {user.firstName} {user.lastName}
  </a> </div>
      {/* <Divider /> */}
    </div>
    
    )
}


  render() {
    const { isLoading, value, results } = this.state
    const userlist = this.state.userList.map((user,key) => {
      return this.usercomponent(user,"q"+key + " item",key);
    })
    return (
      // <List divided relaxed className="active item custom-List">
      //   {userlist}
      // </List>
      <div class="ui secondary vertical menu search-custom">
        <Grid className="">
        <Grid.Column width={6}>
          <Search
            loading={isLoading}
            onResultSelect={this.handleResultSelect}
            onSearchChange={_.debounce(this.handleSearchChange, 500, {
              leading: true,
            })}
            results={results}
            value={value}
            resultRenderer={resultRenderer}
            {...this.props}
          />
        </Grid.Column>
       
      </Grid>
      <div className="user-list-div">
      {userlist}
      </div>
       
  </div>
  

    )
  }
}

export default ListProfile