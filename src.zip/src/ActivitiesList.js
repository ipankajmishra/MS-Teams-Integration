import React, { Component } from 'react'
import { UserOutlined } from '@ant-design/icons';
import axios from 'axios';
// import { Button } from 'semantic-ui-react';
import { List } from 'semantic-ui-react'
import { Avatar } from 'antd';
import { MDBRow, MDBCol } from 'mdbreact';
import { Divider,Accordion, Image, Segment } from 'semantic-ui-react'
import { Button } from 'semantic-ui-react'
import ActivityDetails from './ActivityDetails';
export class ActivitiesList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            myActivities: [],
            arr:[]
        };
        // this.hello();
    }
    addActiveState = (index,activities) =>{
        if(index!==this.state.lastindex){let arr = this.state.arr;
        arr[index]=true;
        arr[this.state.lastindex]=false;
        this.setState({
          lastindex:index,
          arr:arr
        },()=>this.handleGetAssignedActivityDetails(activities))}
    else{
        let arr = this.state.arr;
        arr[index]=false;
          this.setState({
              lastindex:-1,
              arr:arr
          })
      
    }
        
        // $(classname).removeClass(classname);
   
       
      }

      

    componentWillReceiveProps(props) {
        this.setState({
            myActivities: props.myNewActivities,
        })
    }

    handleGetAssignedActivityDetails = (activities) => {
        this.props.myActivityDetails(activities)
    }


    activitiescomponent = (activities,index) => {
        return (
            <Accordion>
            <Accordion.Title>
            <div onClick={()=>{this.addActiveState(index,activities)}} style={{}} className={`${this.state.arr[index]?"activity-class":''}`}>
                <MDBRow>
                    <MDBCol size="1">
                        <Avatar style={{ color: '#f56a00', backgroundColor: '#fde3cf',marginTop:"12px",marginLeft:"" }}>{activities.name.substr(0, 1)}</Avatar>
                    </MDBCol>
                    <MDBCol size="11">
                        <List.Item active style={{marginLeft:"10px",marginRight:"",marginTop:"10px"}}>
                            {/* <List.Icon name='github' size='large' verticalAlign='middle' /> */}
                            <List.Content className="abcd">
                                <List.Header className="activity-name-second-pane" as='a' >{activities.name}
                                <Button.Group className="btn-group disabled">
                            <Button  className={`btn-inside ${activities.category=="learning"?"custom-bg-btn":'disabled'}`}>L</Button>
                            <Button.Or className="btn-inside" />
                            <Button className={`btn-inside ${activities.category==="webinar"?"custom-bg-btn":'disabled'}`}>W</Button>
                            <Button.Or className="btn-inside" />
                            <Button className={`btn-inside ${activities.category==="assessment"?"custom-bg-btn":'disabled'}`}>A</Button>
                        </Button.Group>
                        </List.Header>
                                {/* <br></br><br></br><List.Description as='a'>{activities.description}</List.Description> */}
                                <p style={{marginTop:"10px"}}>{activities.description} <br></br>On May 25, 2018, a new privacy law called the General Data Protection Regulation (GDPR) takes effect in the European Union (EU). </p>
                                {/* <p>sahfhvsghvfsavgvgsvgfvsagvfgvsgvfgvgsvfgsvgfvsgvfgsvfgvsgfvsgfgs fgvsgvfgsvgfvsgvfgsvgvfgsvg</p> */}
                            </List.Content>
                        </List.Item>
                        
                    </MDBCol>
                </MDBRow>
                <Divider style={{marginLeft:""}}></Divider>
            </div>
            </Accordion.Title>
            <Accordion.Content className="accord-content" active={this.state.arr[index]===true}>
            {activities.length !== 0 && <ActivityDetails  myNewActivityDetails={activities}/>} 
            <Divider style={{marginLeft:""}}></Divider>
            </Accordion.Content>
              
            </Accordion>

        )
    }

    render() {
        const myactivities = this.state.myActivities.map((activities,key) => {
            return this.activitiescomponent(activities,key);
        })
        return (
            <List divided relaxed className="custom-list">
                {myactivities}
            </List>
        )
    }
}


export default ActivitiesList;